/*
    Carga la lista de viajes con AJAX
    Usa el servicio rest /api/viajes
    Tiene un retardo de 3 segundos
*/

document.addEventListener("DOMContentLoaded", () => {
  console.log("Prearando carga ajax");

  setTimeout(function () {
    fetch("http://localhost:9015/api/viajes")
      .then((response) => response.json())
      .then((viajes) => {
        const contenedor = document.querySelector("#datos-dinamicos");
        let lista = "";
        for (const viaje of viajes) {
          lista = `${lista}<li>${viaje.destino}</li>`;
        }
        lista = `<h2>Lista de viajes:</h2><ul>${lista}</ul>`;
        contenedor.innerHTML = lista;
      })
      .catch((error) => console.error("Error en la petición fetch:", error));
  }, 3000);
});
