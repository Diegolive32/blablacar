package es.diegolive.blablacar.repository;

import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.entity.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRoleRepository extends JpaRepository<UserRole, Long> {
    public List<UserRole> findByUser(User user);

}
