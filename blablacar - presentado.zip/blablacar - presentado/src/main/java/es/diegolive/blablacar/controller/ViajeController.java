package es.diegolive.blablacar.controller;

import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.entity.Viaje;
import es.diegolive.blablacar.repository.UserRepository;
import es.diegolive.blablacar.repository.ViajeRepository;
import es.diegolive.blablacar.service.EmailService;
import es.diegolive.blablacar.service.FileProcessingService;
import es.diegolive.blablacar.service.UserService;
import es.diegolive.blablacar.service.ViajeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/*
    Controlador de viajes
 */

@Controller
public class ViajeController {

    private static final Logger log = LoggerFactory.getLogger(ViajeController.class);

    @Autowired
    ViajeRepository viajeRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    FileProcessingService fileProcessingService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private ViajeService viajeService;

    @Autowired
    private UserService userService;


    //public ViajeController(UserService userService) { this.userService = userService; }

    // Obtiene el usuario conectado
    private User getCurrentUser() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(username);
    }

    // Lista de viajes
    @GetMapping({"/", "/index"})
    public String home(Model model){

        if (getCurrentUser() == null)  {
            return "inicio";
        }

        List<Viaje> listaViajes = viajeRepository.findAll();
        model.addAttribute("viajes", listaViajes);
        model.addAttribute("currentUser", getCurrentUser().getEmail());
        log.debug("Usuario conectado: {}", getCurrentUser().getEmail());
        return "index";
    }

    // Página de creación de un viaje
    @GetMapping("/viaje/nuevo")
    public String nuevoViaje(Model model) {

        // Obtiene el usuario conectado
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User currentUser = userService.findByEmail(username);

        // Crea el formulario de nuevo-viaje asociado al usuario actual como conductor
        Viaje viaje = new Viaje();
        viaje.setFecha(Date.valueOf(LocalDate.now()));
        viaje.setConductor(currentUser);
        model.addAttribute("viaje", viaje);
        return "nuevo-viaje";
    }


    // Guarda el nuevo viaje con los datos de formulario y el fichero de imagen
    @PostMapping("/viaje/nuevo")
    public String guardarViaje(Viaje viaje, @RequestParam("ficheroImagen") MultipartFile fichero) {
        // guardo el viaje
        viajeRepository.save(viaje);
        // si hay fichero los subo y lo guardo en el viaje
        if(!fichero.isEmpty()){
            String nombreOriginal= fichero.getOriginalFilename();
            String extension= nombreOriginal.substring(nombreOriginal.lastIndexOf(".") + 1);
            String img = "n-" + viaje.getId() + "." + extension;
            String resultadoSubida = fileProcessingService.uploadFile(fichero, img);
            viaje.setImagen(img);
            viajeRepository.save(viaje);
            log.debug("Viaje a {} creado correctamente por {}",viaje.getDestino(),viaje.getConductor().getEmail());
        }

        return "redirect:/";
    }

    // muestra la pantalla de viaje
    @GetMapping("/viaje/ver/{id}")
    public String verViaje(@PathVariable long id, Model model) {
        getCurrentUser();
        Optional<Viaje> viajeOpt = viajeRepository.findById(id);
        if (viajeOpt.isPresent()) {
            Viaje viaje = viajeOpt.get();
            model.addAttribute("viaje", viaje);
            model.addAttribute("reservadas", viaje.getViajero().size());
            model.addAttribute("viajeros", viaje.getViajero());
            String propietario = (getCurrentUser().getId().longValue() == viaje.getConductor().getId().longValue())? "true" : "false";
            model.addAttribute("propietario",propietario);
            return "verviaje";
        } else {
            return "/";
        }
    }

    // reserva un viaje
    // recibe el id del viaje a reservar por el usuario conectado
    @PostMapping("/viaje/ver/{id}")
    public String reservarViaje(@PathVariable long id, Model model, RedirectAttributes redirectAttributes) {

        Viaje viaje = viajeService.reservar(id, getCurrentUser());

        if (viaje == null) {
            model.addAttribute("msg", "No se ha podido realizar la reserva");
            return "verviaje-error";
        } else {
            model.addAttribute("viaje", viaje);
            model.addAttribute("reservadas", viaje.getViajero().size());
            model.addAttribute("viajeros", viaje.getViajero());
            String propietario = (getCurrentUser().getId().longValue() == viaje.getConductor().getId().longValue())? "true" : "false";
            model.addAttribute("propietario",propietario);
            model.addAttribute("msg","Reserva realizada");
            return "verviaje";
        }

    }

    // eliminina el viaje inidicado
    @Transactional
    @GetMapping("/viaje/eliminar/{id}")
    public String eliminarViaje(@PathVariable long id) {
        Optional<Viaje> viaje = viajeRepository.findById(id);
        if (viaje.isPresent()) {
            viajeRepository.deleteById(id);
        }
        return "redirect:/";
    }


    // pruebe de envío de correo
    @GetMapping("/pruebacorreo")
    public String pruebacorreo(Model model) {
        emailService.enviarCorreo("diegoantonio.s244148@cesurformacion.com", "Diego", "Funciona");
        return "redirect:/";
    }


}
