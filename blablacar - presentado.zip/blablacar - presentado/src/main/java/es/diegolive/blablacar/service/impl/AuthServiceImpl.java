package es.diegolive.blablacar.service.impl;

import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.repository.UserRepository;
import es.diegolive.blablacar.service.AuthService;
import es.diegolive.blablacar.util.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    public String authenticate(String username, String password) {
        // comprueba el usuario en la base de datos
        User userOpt = userRepository.findByEmail(username);
        if (userOpt !=null && passwordEncoder.matches(password, userOpt.getPassword())) {
            // genera un nuevo jwt toke y lo devuelve
            return jwtUtil.generateToken(username);
        }
        throw new RuntimeException("Credenciales inválidas");
    }
}
