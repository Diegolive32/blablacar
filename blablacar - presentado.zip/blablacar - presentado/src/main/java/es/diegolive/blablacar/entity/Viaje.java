package es.diegolive.blablacar.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Date;
import java.sql.Time;
import java.util.Set;

@Entity
@Data
public class Viaje {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    private User conductor;

    private Date fecha;
    private Time hora;

    private String destino;
    private String vehiculo;
    private int plazas;
    private float precio;
    private String notas;
    private String imagen;

    @ManyToMany
    private Set<User> viajero;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getConductor() {
        return conductor;
    }

    public void setConductor(User conductor) {
        this.conductor = conductor;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(String vehiculo) {
        this.vehiculo = vehiculo;
    }

    public int getPlazas() {
        return plazas;
    }

    public void setPlazas(int plazas) {
        this.plazas = plazas;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getNotas() {
        return notas;
    }

    public void setNotas(String notas) {
        this.notas = notas;
    }

    public Set<User> getViajero() {
        return viajero;
    }

    public void setViajero(Set<User> viajero) {
        this.viajero = viajero;
    }

    public void addViajero(User viajero) {
        this.viajero.add(viajero);
    }

    public void removeViajero(User viajero) {
        this.viajero.remove(viajero);
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
}
