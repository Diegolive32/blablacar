package es.diegolive.blablacar.dto;


import jakarta.validation.constraints.NotEmpty;

import java.sql.Date;
import java.sql.Time;
import java.util.Set;

public class ViajeDto {

    private long id;
    @NotEmpty
    private long conductorId;
    @NotEmpty
    private Date fecha;
    @NotEmpty
    private Time hora;
    @NotEmpty
    private String destino;
    @NotEmpty
    private String vehiculo;
    @NotEmpty
    private int plazas;
    @NotEmpty
    private float precio;
    private String notas;
    private Set<Long> viajerosIds;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @NotEmpty
    public long getConductorId() {
        return conductorId;
    }

    public void setConductorId(@NotEmpty(message = "Debe indicar el conductor") long conductorId) {
        this.conductorId = conductorId;
    }

    public @NotEmpty Date getFecha() {
        return fecha;
    }

    public void setFecha(@NotEmpty Date fecha) {
        this.fecha = fecha;
    }

    public @NotEmpty Time getHora() {
        return hora;
    }

    public void setHora(@NotEmpty Time hora) {
        this.hora = hora;
    }

    public @NotEmpty String getDestino() {
        return destino;
    }

    public void setDestino(@NotEmpty String destino) {
        this.destino = destino;
    }

    public @NotEmpty String getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(@NotEmpty String vehiculo) {
        this.vehiculo = vehiculo;
    }

    @NotEmpty
    public int getPlazas() {
        return plazas;
    }

    public void setPlazas(@NotEmpty int plazas) {
        this.plazas = plazas;
    }

    @NotEmpty
    public float getPrecio() {
        return precio;
    }

    public void setPrecio(@NotEmpty float precio) {
        this.precio = precio;
    }

    public String getNotas() {
        return notas;
    }

    public void setNotas(String notas) {
        this.notas = notas;
    }

    public Set<Long> getViajerosIds() {
        return viajerosIds;
    }

    public void setViajerosIds(Set<Long> viajerosIds) {
        this.viajerosIds = viajerosIds;
    }
}
