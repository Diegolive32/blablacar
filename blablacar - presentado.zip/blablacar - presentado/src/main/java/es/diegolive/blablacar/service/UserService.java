package es.diegolive.blablacar.service;

import es.diegolive.blablacar.dto.UserDto;
import es.diegolive.blablacar.entity.Role;
import es.diegolive.blablacar.entity.User;

import java.util.List;

/*
    Servicio de Usuarios
 */

public interface UserService {
    void saveUser(UserDto userDto);

    User findByEmail(String email);

    List<UserDto> findAllUsers();

    public UserDto convertEntityToDto(User user);
    public void save(User user);

    public List<Role> conseguirRolesByUser(User user);
    public void saveCifrandoPassword(User user);
}
