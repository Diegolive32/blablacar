package es.diegolive.blablacar.controller;

import es.diegolive.blablacar.repository.UserRepository;
import es.diegolive.blablacar.repository.ViajeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/*
    Controlador del panel de administración
    Muestra los usuarios y viajes activos
 */

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    ViajeRepository viajeRepository;

    @GetMapping({"","/"})
    public String adminHome(Model model){
        int numViajes = viajeRepository.findAll().size();
        int numUsers = userRepository.findAll().size();
        model.addAttribute("viajes", numViajes);    // Atributo de información de viajes
        model.addAttribute("users", numUsers);      // Atributo de información de usuario
        return "admin";
    }

}
