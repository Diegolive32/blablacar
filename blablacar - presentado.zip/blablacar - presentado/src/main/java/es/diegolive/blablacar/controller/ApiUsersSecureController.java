package es.diegolive.blablacar.controller;


import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.repository.UserRepository;
import es.diegolive.blablacar.util.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
    Controlador Servicio REST de ususarios
    Autorización mediante JWT token en header Bearer
 */

@RestController
@RequestMapping("/api/users")
public class ApiUsersSecureController {

    Logger log = LoggerFactory.getLogger(ApiUsersSecureController.class);

    JwtUtil jwtUtil = new JwtUtil();

    @Autowired
    UserRepository userRepository;

    // Devuelve todos los usuarios
    @GetMapping({"","/"})
    public List<User> getAll(@RequestHeader(name="Authorization") String token){
        // Lee el header "Authorization" y le quita el texto "Bearer "
        String jwt = token.replaceAll("Bearer ","");
        // Valida el token JWT y si no es válido no devuelve nada
        if (jwtUtil.validateToken(jwt)) {
            return userRepository.findAll();
        } else {
            return null;
        }
    }

    // Devuelve los datos de un usuario por email/username
    @GetMapping("/{username}")
    public User getById(@PathVariable("username") String username, @RequestHeader(name="Authorization") String token){
        // Lee el header "Authorization" y le quita el texto "Bearer "
        String jwt = token.replaceAll("Bearer ","");
        if (jwtUtil.validateToken(jwt)) {
            // Valida el token JWT y si no es válido no devuelve nada
            return userRepository.findByEmail(username);
        } else {
            return null;
        }
    }


}


