package es.diegolive.blablacar.controller;

import com.paypal.api.payments.*;
import com.paypal.base.rest.APIContext;
import com.paypal.base.rest.PayPalRESTException;
import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/*
    Controlador para los pagos por PayPal
 */

@Controller
@RequestMapping("/paypal")
public class PaypalController {

    @Autowired
    private APIContext apiContext;

    @Autowired
    private UserService userService;

    // Base URL de la aplicación
    private static final String BASE_URL = "http://localhost:9015";

    // Pago indicando el importe y el usuario
    @GetMapping("/pay")
    public String pay(@RequestParam("importe") BigDecimal importe,
                      @RequestParam("userEmail") String userEmail,
                      RedirectAttributes redirectAttributes) {
        String successUrl = BASE_URL + "/paypal/success?importe=" + importe.toPlainString() + "&userEmail=" + userEmail;
        String cancelUrl = BASE_URL + "/paypal/cancel";

        Amount amount = new Amount();
        amount.setCurrency("EUR");
        amount.setTotal(importe.toPlainString());

        Transaction transaction = new Transaction();
        transaction.setDescription("Recarga de saldo");
        transaction.setAmount(amount);

        List<Transaction> transactions = new ArrayList<>();
        transactions.add(transaction);

        Payer payer = new Payer();
        payer.setPaymentMethod("paypal");

        Payment payment = new Payment();
        payment.setIntent("sale");
        payment.setPayer(payer);
        payment.setTransactions(transactions);

        RedirectUrls redirectUrls = new RedirectUrls();
        redirectUrls.setCancelUrl(cancelUrl);
        redirectUrls.setReturnUrl(successUrl);
        payment.setRedirectUrls(redirectUrls);

        try {
            Payment createdPayment = payment.create(apiContext);
            for (Links link : createdPayment.getLinks()) {
                if ("approval_url".equalsIgnoreCase(link.getRel())) {
                    return "redirect:" + link.getHref();
                }
            }
        } catch (PayPalRESTException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "Error al procesar el pago con PayPal.");
            return "redirect:/recargar";
        }
        redirectAttributes.addFlashAttribute("error", "No se pudo obtener la URL de confirmación de PayPal.");
        return "redirect:/recargar";
    }

    // Pago correcto
    @GetMapping("/success")
    public String successPay(@RequestParam("paymentId") String paymentId,
                             @RequestParam("PayerID") String payerId,
                             @RequestParam("importe") BigDecimal importe,
                             @RequestParam("userEmail") String userEmail,
                             RedirectAttributes redirectAttributes) {
        Payment payment = new Payment();
        payment.setId(paymentId);
        PaymentExecution paymentExecution = new PaymentExecution();
        paymentExecution.setPayerId(payerId);
        try {
            Payment executedPayment = payment.execute(apiContext, paymentExecution);
            // Actualizo el saldo del usuario
            User user = userService.findByEmail(userEmail);
            if (user != null) {
                user.setSaldo(user.getSaldo().add(importe));
                userService.save(user);
                redirectAttributes.addFlashAttribute("success", "Saldo recargado correctamente.");
            }
            // Vuelve a la página de usuario para ver el nuevo saldo
            return "redirect:/user";
        } catch (PayPalRESTException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "Error al ejecutar la recarga: " + e.getMessage());
            return "redirect:/recargar";
        }
    }

    @GetMapping("/cancel")
    public String cancelPay(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("error", "La recarga fue cancelada.");
        return "redirect:/recargar";
    }
}
