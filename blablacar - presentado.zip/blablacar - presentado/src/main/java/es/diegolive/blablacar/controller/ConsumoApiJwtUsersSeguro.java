package es.diegolive.blablacar.controller;

import es.diegolive.blablacar.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import es.diegolive.blablacar.entity.User;

/*
    Prueba la API de usuarios segura
    Obtiene el token JWT
    Lo pasa para leer los datos
 */
@Controller
public class ConsumoApiJwtUsersSeguro {

    @Autowired
    JwtUtil jwtUtil;

    static final String API_JWT_URL = "http://localhost:9015/api/jwt/auth?username=diegolivejr@gmail.com&password=123456";
    static final String API_USERS_URL = "http://localhost:9015/api/users";

    @GetMapping("/consume-api")
    public String verUsuarios(Model model) {

        // Voy a llamar a las apis usando RestTemplate
        RestTemplate restTemplate = new RestTemplate();

        // Obtengo el token JWT llamando al servicio
        String token = restTemplate.getForObject(API_JWT_URL, String.class);

        // Añado el JWT a la cabecera de la peticón HTTP
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        // Crea la solicitud HTTP
        HttpEntity<String> request = new HttpEntity<>(headers);

        // Realiza la solicitud GET
        ResponseEntity<List<User>> response = restTemplate.exchange(
                API_USERS_URL,
                HttpMethod.GET,
                request,
                new ParameterizedTypeReference<List<User>>() {}
        );

        // Procesa la respuesta
        if (response.getStatusCode().is2xxSuccessful()) {
            List<User> usuarios = response.getBody();
            model.addAttribute("users",usuarios);
            model.addAttribute("jwt",token);
            model.addAttribute("url",API_USERS_URL);
            return "consume-api";
        } else {
            System.err.println("Error: " + response.getStatusCode());
            return null;
        }
    }


}
