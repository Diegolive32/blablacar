package es.diegolive.blablacar.service;

/*
    Servicio de autenticación de usuario con JWT
 */

public interface AuthService {
    // devuelve el token jwt si el usuario es correcto
    public String authenticate(String username, String password);
}
