package es.diegolive.blablacar.controller;

import es.diegolive.blablacar.repository.ViajeRepository;
import es.diegolive.blablacar.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/*
    Controlador para generar el token JWT a partir del usuario y la contraseña
    Se validan en la base datos
 */

@RestController
@RequestMapping("/api/jwt")
public class ApiJwtController {

    @Autowired
    ViajeRepository viajeRepository;

    @Autowired
    AuthService authService;

    @GetMapping("/auth")
    public String auth(@RequestParam("username") String username, @RequestParam("password") String password) {
        return authService.authenticate(username,password);

    }

}

