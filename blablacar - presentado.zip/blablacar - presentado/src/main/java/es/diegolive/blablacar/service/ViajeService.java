package es.diegolive.blablacar.service;

import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.entity.Viaje;

public interface ViajeService {
    public Viaje reservar(long viajeId, User viajero);
}
