package es.diegolive.blablacar.iniciarbbdd;

import es.diegolive.blablacar.entity.Role;
import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.entity.UserRole;
import es.diegolive.blablacar.entity.Viaje;
import es.diegolive.blablacar.repository.RoleRepository;
import es.diegolive.blablacar.repository.UserRepository;
import es.diegolive.blablacar.repository.UserRoleRepository;
import es.diegolive.blablacar.repository.ViajeRepository;
import es.diegolive.blablacar.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.Time;
import java.util.Calendar;

/*
    CommandLineRunner para inicializar los datos
    Crea un usuario adminstrador
 */

@Component
public class CrearBBBDD implements CommandLineRunner{
    @Autowired
    UserRoleRepository userRoleRepository;
    @Autowired
    UserService userService;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    ViajeRepository viajeRepository;
    @Override
    public void run(String... args) throws Exception {


        if(roleRepository.findAll().isEmpty()) {
            System.out.println("----------------------- CREANDO BD -------------------------");
            Role roleAdmin = new Role();
            roleAdmin.setName("ROLE_ADMIN");
            roleRepository.save(roleAdmin);

            Role roleUser = new Role();
            roleUser.setName("ROLE_USER");
            roleRepository.save(roleUser);

            // Creo el usuario administrador
            User user = new User();
            user.setName("Diego Antonio Alcaraz López");
            user.setEmail("diegolivejr@gmail.com");
            user.setPassword("123456");
            user.setSaldo(0);
            userService.saveCifrandoPassword(user);

            //Le asigno rol de ADMIN
            UserRole userRole = new UserRole();
            userRole.setRole(roleAdmin); //role es el de admin
            userRole.setUser(user);
            userRoleRepository.save(userRole);

            //Le asigno rol de USER
            UserRole userRole2 = new UserRole();
            userRole2.setRole(roleUser); //role es el de user
            userRole2.setUser(user);
            userRoleRepository.save(userRole2);

            // Creo el usuario conductor
            User conductor = new User();
            conductor.setName("Fernando Alonso");
            conductor.setEmail("conductor@pruebas.com");
            conductor.setPassword("123456");
            conductor.setSaldo(0);
            userService.saveCifrandoPassword(conductor);

            //Le asigno rol de USER
            UserRole userRoleConductor = new UserRole();
            userRoleConductor.setRole(roleUser); //role es el de user
            userRoleConductor.setUser(conductor);
            userRoleRepository.save(userRoleConductor);

            // Creo el usuario viajero
            User viajero = new User();
            viajero.setName("Willy Fog");
            viajero.setEmail("viajero@pruebas.com");
            viajero.setPassword("123456");
            viajero.setSaldo(0);
            userService.saveCifrandoPassword(viajero);

            //Le asigno rol de USER
            UserRole userRoleViajero = new UserRole();
            userRoleViajero.setRole(roleUser); //role es el de user
            userRoleViajero.setUser(viajero);
            userRoleRepository.save(userRoleViajero);

            // creo un viaje
            Viaje viaje = new Viaje();
            viaje.setConductor(conductor);
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, 10);
            viaje.setFecha(new java.sql.Date(cal.getTime().getTime()));
            viaje.setHora(new java.sql.Time(cal.getTime().getTime()));
            viaje.setDestino("Cartagena");
            viaje.setVehiculo("Audi A4 Blanco");
            viaje.setPlazas(2);
            viaje.setPrecio(30f);
            viaje.setNotas("Viaje de pruebas");
            viaje.setImagen("audi.jpg");
            viajeRepository.save(viaje);
        }
        System.out.println("------------------------------------------------------------");

    }
}
