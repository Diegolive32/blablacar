package es.diegolive.blablacar.repository;

import es.diegolive.blablacar.entity.Viaje;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ValoracionRepository extends JpaRepository<Viaje, Long> {

}