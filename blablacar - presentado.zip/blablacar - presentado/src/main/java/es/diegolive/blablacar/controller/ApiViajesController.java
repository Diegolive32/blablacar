package es.diegolive.blablacar.controller;

import es.diegolive.blablacar.entity.Viaje;
import es.diegolive.blablacar.repository.ViajeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

/*
    Controlador del servicio rest de viajes
 */
@RestController
@RequestMapping("/api/viajes")
public class ApiViajesController {

    @Autowired
    ViajeRepository viajeRepository;

    // Devuelve todos los viajes
    @GetMapping({"","/"})
    public List<Viaje> getAll(){
        return viajeRepository.findAll();
    }

    // Devuelve un viaje por id
    @GetMapping("/{id}")
    public Optional<Viaje> getById(@PathVariable("id") Long id){
        return viajeRepository.findById(id);
    }


}



