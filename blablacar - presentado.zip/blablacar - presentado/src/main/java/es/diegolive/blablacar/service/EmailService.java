package es.diegolive.blablacar.service;

/*
    Servicio para enviar emails
 */

public interface EmailService {
    // envia un correo al destinatario
    public void enviarCorreo(String destinatario, String asunto, String mensaje);
}

