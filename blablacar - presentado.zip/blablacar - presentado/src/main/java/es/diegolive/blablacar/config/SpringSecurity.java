package es.diegolive.blablacar.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/*
    Configuración de la seguridad de la aplicación
    Dos roles ADMIN y USER
 */
@Configuration
@EnableWebSecurity
public class SpringSecurity {

    @Autowired
    private UserDetailsService userDetailsService;

    @Bean
    public static PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
                // Configuración de acceso a las rutas
                .authorizeHttpRequests((authorize) ->
                        authorize
                                .requestMatchers("/index", "/", "/inicio").permitAll()
                                .requestMatchers("/viaje/**").hasRole("USER")
                                .requestMatchers("/viaje/ver/**").hasRole("USER")
                                .requestMatchers("/user").hasAnyRole("USER","ADMIN")
                                .requestMatchers("/users").hasRole("ADMIN")
                                .requestMatchers("/admin","/admin/**").hasRole("ADMIN")
                                .requestMatchers("/register/**").permitAll()
                                .requestMatchers("/file/**").permitAll()
                                .requestMatchers("/api/**").permitAll()
                                .requestMatchers("/api/viajes/**").permitAll()
                                .requestMatchers("/api/jwt/**").permitAll()
                                .requestMatchers("/**").permitAll()
                // Configuración de la página de login
                ).formLogin(
                        form -> form
                                .loginPage("/login")
                                .loginProcessingUrl("/login")
                                .defaultSuccessUrl("/")
                                .permitAll()
                // Configuración de la página de logout
                ).logout(
                        logout -> logout
                                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                                .logoutSuccessUrl("/")
                                .permitAll()
                );
        return http.build();
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());
        // Autenticación con usuario y password
    }
}
