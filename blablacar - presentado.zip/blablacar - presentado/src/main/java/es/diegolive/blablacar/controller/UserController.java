package es.diegolive.blablacar.controller;

import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.security.Principal;

/*
    Controlador de usuario
    Muestra los datos del usuario y permite recargar saldo
 */

@Controller
public class UserController {

    @Autowired
    UserService userService;


    // Muestra los datos del usuario
    @GetMapping("/user")
    public String verUsuario(Model model) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User currentUser = userService.findByEmail(username);

        model.addAttribute("user", currentUser);
        return "user";
    }


    // Muestra la página de recarga
    @GetMapping("/recargar")
    public String recargarForm() {
        return "recargar"; // Vista recargar.html
    }

    // Llama a PayPal para recargar
    @PostMapping("/recargar")
    public String recargarSaldo(@RequestParam("importe") BigDecimal monto, Principal principal, RedirectAttributes redirectAttributes) {
        User user = userService.findByEmail(principal.getName());
        if (user != null) {
            return "redirect:/paypal/pay?importe=" + monto.toPlainString() + "&userEmail=" + user.getEmail();
        }
        redirectAttributes.addFlashAttribute("error", "Usuario no encontrado.");
        return "redirect:/recargar";
    }

}
