package es.diegolive.blablacar.service.impl;

import es.diegolive.blablacar.entity.User;
import es.diegolive.blablacar.entity.Viaje;
import es.diegolive.blablacar.repository.UserRepository;
import es.diegolive.blablacar.repository.ViajeRepository;
import es.diegolive.blablacar.service.EmailService;
import es.diegolive.blablacar.service.ViajeService;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.Set;

@Service
public class ViajeServiceImpl implements ViajeService {

    private static final Logger log = LoggerFactory.getLogger(ViajeServiceImpl.class);

    @Autowired
    ViajeRepository viajeRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    EmailService emailService;

    /*
        Reserva un viaje
        Si está lleno o no existe devuelve null
     */
    @Transactional
    public Viaje reservar(long viajeId, User viajero) {
        Optional<Viaje> viajeOpt = viajeRepository.findById(viajeId);
        if (!viajeOpt.isPresent())
            return null;
        Viaje viaje = viajeOpt.get();

        // Compruebo y ya está esta todo reservado devuelve null
        Set<User> viajeros = viaje.getViajero();
        if (viajeros.size() >= viaje.getPlazas()) {
            log.error("El viaje a {} ya está completo", viaje.getDestino());
            return null;
        }

        // Compruebo que el viajero tiene saldo suficiente
        if (viajero.getSaldo().floatValue() < viaje.getPrecio()) {
            log.error("El viajero {} no tiene saldo suficiente para viajar", viajero.getEmail());
            return null;
        }


        // Paso el dinero del saldo del viajero al conductor
        viajero.setSaldo(viajero.getSaldo().floatValue() - viaje.getPrecio());
        User conductor = viaje.getConductor();
        conductor.setSaldo(conductor.getSaldo().floatValue() + viaje.getPrecio());
        userRepository.save(viajero);
        userRepository.save(conductor);

        // Añade el viajero y guarda el viaje
        viaje.addViajero(viajero);
        viajeRepository.save(viaje);

        // Envia un mensaje al conductor
        emailService.enviarCorreo(viaje.getConductor().getEmail(),"Nueva reserva","El usuario "+viajero.getName()+" ("+viajero.getEmail()+") ha reservado tu viaje a "+viaje.getDestino()+".");
        return viaje;
    }

}
