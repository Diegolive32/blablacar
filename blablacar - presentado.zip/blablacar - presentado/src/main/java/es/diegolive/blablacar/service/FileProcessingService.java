package es.diegolive.blablacar.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/*
    Servicio para la gestión de ficheros
 */

public interface FileProcessingService {
    List<String> fileList();

    String uploadFile(MultipartFile file, String fileName);

    Resource downloadFile(String fileName);
}
